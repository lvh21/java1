package java1;
import java.util.Scanner;
public class Java31 {
    public static void main(String[] args) {
        Scanner n = new Scanner(System.in);
        int a = n.nextInt();
        int b = n.nextInt();
        System.out.println(a > b);
    }
}
