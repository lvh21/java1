package java1;

public class Java15 {
    public static void main(String[] args){
        System.out.println("Area = " + (7.5*3.8));
    }
}
