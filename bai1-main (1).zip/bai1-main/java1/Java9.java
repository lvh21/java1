package java1;

public class Java9 {
    public static void main(String[] args) {
        int a =254, b = 343;
        System.out.println("a + b = " + (a + b));
    }
}
