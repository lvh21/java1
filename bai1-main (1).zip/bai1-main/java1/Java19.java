package java1;

public class Java19 {
    public static void main(String[] args) {
        boolean b = true;
        System.out.println(b);
    }
}
