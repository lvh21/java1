package java1;

public class Java10 {
    public static void main(String[] args){
        int a=8343, b=6453;
        System.out.println("a - b = " + (a-b));
    }
}
