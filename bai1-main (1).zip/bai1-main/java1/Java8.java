package java1;
public class Java8 {
    public static void main(String[] args) {
        System.out.println("2468 + 1234 = " + (2468+1234));
        System.out.println("2468 -1234 = " + (2468-1234));
        System.out.println("2468 * 1234 = " + (2468*1234));
        System.out.println("2468 / 1234 = " + (2468/1234));

    }
}
