package java1;

public class Java17 {
    public static void main(String[] args) {
        char d = 'a' + 3;
        System.out.println(d);
    }
}
