package java1;
public class Java7 {
    public static void main(String[] args) {
        System.out.println("125 + 206 = " + (125 + 206));
    }
}
