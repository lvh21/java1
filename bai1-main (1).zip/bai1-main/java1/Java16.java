package java1;

public class Java16 {
    public static void main(String[] args) {
        char c = 'x';
        System.out.println(c);
    }
}
