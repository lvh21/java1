package java1;

public class Java20 {
    public static void main(String[] args){
        short a=-1000, b=1000;
        System.out.println(a);
        System.out.println(b);
    }

}
