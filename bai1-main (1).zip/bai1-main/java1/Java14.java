package java1;

public class Java14 {
    public static void main(String[] args){
        double a=10.5, b=7;
        System.out.println("a / b = " + (a/b));
    }
}
