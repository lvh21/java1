package java1;
import java.util.Scanner;
public class Java22 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String address = sc.nextLine();
        System.out.println("Name: "+ name);
        System.out.println("Address: "+ address);
    }
}
