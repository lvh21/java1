package java1;

public class Java11 {
    public static void main(String[] args){
        int a = 6, b = 2;
        System.out.println("a + b = " + (a+b));
        System.out.println("a - b = " + (a-b));
        System.out.println("a * b = " + (a*b));
        System.out.println("a / b = " + (a/b));
    }
}
