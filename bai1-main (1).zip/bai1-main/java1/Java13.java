package java1;

public class Java13 {
    public static void main(String[] args){
        String name = "Codelearn";
        int bob = 2019;
        System.out.println("Name: " + name);
        System.out.println("Date of birth: " + bob);
    }
}
