package java1;
import java.util.Scanner;
public class Java30 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char c = (char)(sc.next().charAt(0) + 1);
        System.out.println(c);
    }
}
