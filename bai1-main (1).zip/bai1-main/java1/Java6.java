package java1;
public class Java6 {
    public static void main(String[] args) {
        System.out.println(37 * 56);
    }
}
