package java1;
public class Java3 {
    public static void main(String[]args) {
        System.out.println("Name: Codelearn\nDate of birth: 2019");
    }
}
