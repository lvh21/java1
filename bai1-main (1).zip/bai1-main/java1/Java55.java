package java1;

public class Java55 {
    public static void main(String[] args){
        for (int i = 1; i <= 100; i++) {
            if (i == 51) {
                break;
            }
            System.out.println(i);
        }
    }
}
