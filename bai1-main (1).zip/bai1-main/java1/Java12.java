package java1;

public class Java12 {
    public static void main(String[] args){
        String name = "Codelearn";
        System.out.println("Hello " + name);
    }
}
