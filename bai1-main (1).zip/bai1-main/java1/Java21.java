package java1;
import java.util.Scanner;
public class Java21 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Hello " + sc.next());
    }
}
