package java1;
public class Java2 {
    public static void main(String[]args) {
        System.out.println("Codelearn");
    }
}
