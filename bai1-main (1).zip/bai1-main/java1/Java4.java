package java1;
public class Java4 {
    public static void main(String[] args) {
        System.out.println(313 + 122);
    }
}
