/*
A simple Java program to display "Hello, World!" on the screen
using System.out.println() statement
*/
package java1;
public class Java5
{
    public static void main(String[] args)
    {
        // Display Hello World on the screen
        System.out.println("Hello, World!");
    }
}
