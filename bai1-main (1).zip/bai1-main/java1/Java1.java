package java1;
public class Java1 {
    public static void main(String[]args) {
        System.out.println("Hello, World!");
    }
}
