package java1;

public class Java18 {
    public static void main(String[] args){
        int a = 384847522, b = 988347273;
        System.out.println((long)a*b);
    }
}
